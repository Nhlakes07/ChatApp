package com.example.myapplication.models;

import java.io.Serializable;

public class Users implements Serializable
{
    public String Name,Surname,Token ,Email,id,PhoneNumber,image;
}
