package com.example.myapplication.listeners;

import com.example.myapplication.models.Users;

public interface UserListener
{
    void onUserClicked(Users users);
}
